<?php
namespace Craft;

define('CRAFT_VERSION', '2.4');
define('CRAFT_BUILD', '2682');
define('CRAFT_SCHEMA_VERSION', '2.4.0');
define('CRAFT_RELEASE_DATE', '1438196317');
define('CRAFT_MIN_BUILD_REQUIRED', '2570');
define('CRAFT_MIN_BUILD_URL', 'http://download.buildwithcraft.com/craft/2.1/2.1.2570/Craft-2.1.2570.zip');
define('CRAFT_TRACK', 'stable');
